﻿using ITService.Models;
using Microsoft.AspNetCore.Mvc;

namespace ITService.Controllers
{
    public class AccountController : Controller
    {
        private readonly IConfiguration _configuration;

        public AccountController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Kullanıcı doğrulama kodunu burada yapın
                // Veritabanı kontrolü yapılacak
            }
            return View(model);
        }
    }

}
